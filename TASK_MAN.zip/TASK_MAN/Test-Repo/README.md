#
This app provides its users a platform to save tasks to be done by them.
It will allow them to track their progress and change status of the tasks when it’s processing or completed.
And this app will definitely help the users to schedule their daily activities and manage their time in a best way.
***
# Team (Group 5)
* Lakhveer Singh
* Gopika Ajith
* Christeena Karunattu Sunny
* Manmohan Singh
# Features
* Users can add tasks to their to do list
* Users can see all the tasks in the task list
* Users can edit their task
* Users can delete their tasks
* Users can clear all tasks
* They tasks can be saved in local storage
* The tasks can be sorted 
* Toast will be shown when a task is added, edited or deleted
* A reminder can be set
* Will show message if not the task
* There will be alerts
* The completed tasks can be cleared or can be changed to another color
* They can select a date which they think the task could be completed
* Users can update when they starts working on the task
* Users can update the status as completed when a task is completed.
* Users will be able to set priorities for each task by selecting specific colours for high, Medium and low priority

# Specs
1) Android Studio with Java programming language
2) For now only work on Android devices
3) Users can save tasks that have to be done

# Out Of Scope
1) No videos or images can be uploaded, only texts can be used